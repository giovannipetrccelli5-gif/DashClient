100 original DashClient HUD mini-mods for Minecraft 26.1.2.
Extract this archive, then install only desired individual .jar addons alongside DashClient 2.0 and Fabric API.
All addons require the same Minecraft version as DashClient.
Do not install all 100 or multiple styles of the same metric: overlays may overlap or reduce FPS.
Sodium and Lithium are third-party mods; download them separately from their original maintainers.
